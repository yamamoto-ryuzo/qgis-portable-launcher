# 検索簡易フィルタープラグイン

属性情報のフィルターによって検索するQGISプラグインです。


## 概要

### 検索画面

![](images/image_01.PNG)

### フィルター設定メニュー
![](images/image_02.PNG)

### テキストフィルター
![](images/image_03.PNG)


![](images/image_04.PNG)


## 利用方法

利用方法については、[使い方](./MANUAL.md)をご確認ください。


## ライセンス

本ツールは GNU GENERAL PUBLIC LICENSE v2 ライセンスが設定されています。[GNU GENERAL PUBLIC LICENSE Version 2, June 1991](https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt)