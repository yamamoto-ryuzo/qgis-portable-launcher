def classFactory(iface):
    from .searchLayers import SearchLayers
    return SearchLayers(iface)
