SPDX-License-Identifier: CC0-1.0

All svg images were created with SVGEdit [0], compressed with SVGOMG [1]

and released under the Creative Commons Zero v1.0 Universal.

[0] https://github.com/SVG-Edit/svgedit
[1] https://github.com/jakearchibald/svgomg
