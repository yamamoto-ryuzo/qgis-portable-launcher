
def convert(geostyler):
    return {}, [] # (dictionary with ArcGIS Pro style, list of warnings)
