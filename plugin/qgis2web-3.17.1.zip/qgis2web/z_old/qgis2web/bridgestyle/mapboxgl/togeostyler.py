def convert(style):
    pass  # TODO
